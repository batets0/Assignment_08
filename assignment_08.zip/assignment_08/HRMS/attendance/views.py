from django.shortcuts import render
from attendance.models import AttendanceForm
from attendance.models import Attendance

# Create your views here.
def index(request):
    return render(request, 'attendance/index.html')

def ListAttendances(request):
    attendances = Attendance.objects.all()
    return render(request, 'attendance/attendance_list.html', {'attendances': attendances})

def AddAttendance(request):
    form = AttendanceForm()
    if request.method == 'POST':
        form = AttendanceForm(request.POST)
        if form.is_valid():
            form.save()
        return index(request)   
    return render(request, 'attendance/add_attendance.html', {'form': form})



