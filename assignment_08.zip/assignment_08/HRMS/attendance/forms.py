from django import forms
from attendance.models import Attendance

# Create your forms here.
class AttendanceForm(forms.ModelForm):
    class Meta:
        model = Attendance
        fields = '__all__'