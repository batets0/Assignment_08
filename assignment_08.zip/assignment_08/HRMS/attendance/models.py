from django.db import models
from HRMS.employee.models import Employee

# Create your models here.
class Attendance(models.Model):
    attendance_id = models.AutoField(primary_key=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    attendance_date = models.DateField()
    status = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.employee.name} - {self.attendance_date}"
