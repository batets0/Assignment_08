from django.shortcuts import render
from training.models import TrainingForm
from training.models import Training
# Create your views here.

def list_training(request):
    training = Training.objects.all()
    return render(request, 'training/training_list.html', {'training': training})

def add_training(request):
    form = TrainingForm()
    if request.method == 'POST':
        form = TrainingForm(request.POST)
        if form.is_valid():
            form.save()
        return list_training(request)
    return render(request, 'training/add_training.html', {'form': form})
