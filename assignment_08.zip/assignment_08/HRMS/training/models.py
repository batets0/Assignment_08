from django.db import models

# Create your models here.
class Training(models.Model):
    training_id = models.AutoField(primary_key=True)
    training_name = models.CharField(max_length=255)
    training_date = models.DateField()

    def __str__(self):
        return self.training_name
