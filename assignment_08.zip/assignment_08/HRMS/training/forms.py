from django import forms
from training.models import Training

class TrainingForm(forms.ModelForm):
    class Meta:
        model = Training
        fields = '__all__'