from django.shortcuts import render
from employee.models import EmployeeForm
from employee.models import Employee

# Create your views here.
def index(request):
    return render(request, 'employee/index.html')

def ListEmployees(request):
    employees = Employee.objects.all()
    return render(request, 'employee/employee_list.html', {'employees': employees})

def AddEmployee(request):
    form = EmployeeForm()
    if request.method == 'POST':
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
        return index(request)   
    return render(request, 'employee/add_employee.html', {'form': form})