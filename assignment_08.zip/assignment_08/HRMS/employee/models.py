from django.db import models

from HRMS.department.models import Department
from HRMS.position.models import Position
from HRMS.project.models import Project
from HRMS.training.models import Training

# Create your models here.
class Employee(models.Model):
    employee_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    dob = models.DateField()
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    position = models.ForeignKey(Position, on_delete=models.CASCADE)
    trainings = models.ManyToManyField(Training, through='EmployeeTraining')  # Many-to-Many through EmployeeTraining
    projects = models.ManyToManyField(Project, through='EmployeeProject')  # Many-to-Many through EmployeeProject

    def __str__(self):
        return self.name
