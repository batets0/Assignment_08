from django.db import models

from HRMS.employee.models import Employee

# Create your models here.
class PerformanceReview(models.Model):
    review_id = models.AutoField(primary_key=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    review_date = models.DateField()
    score = models.IntegerField()
    comments = models.TextField()

    def __str__(self):
        return f"{self.employee.name} - {self.review_date}"
