from django.shortcuts import render
from performance_review.models import PerformanceReviewForm
from performance_review.models import PerformanceReview
# Create your views here.

def index(request):
    return render(request, 'performance_review/index.html')

def AddPerformanceReview(request):
    form = PerformanceReviewForm()
    if request.method == 'POST':
        form = PerformanceReviewForm(request.POST)
        if form.is_valid():
            form.save()
        return index(request)   
    return render(request, 'performance_review/add_performance_review.html', {'form': form})

def ListPerformanceReviews(request):
    performance_reviews = PerformanceReview.objects.all()
    return render(request, 'performance_review/performance_review_list.html', {'performance_reviews': performance_reviews})
