from django import forms
from performance_review.models import PerformanceReview

class PerformanceReviewForm(forms.ModelForm):
    class Meta:
        model = PerformanceReview
        fields = '__all__'