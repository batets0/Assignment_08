from django.shortcuts import render
from project.models import ProjectForm
from project.models import Project
# Create your views here.

def index(request):
    return render(request, 'project/index.html')

def AddProject(request):
    form = ProjectForm()
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            form.save()
        return index(request)   
    return render(request, 'project/add_project.html', {'form': form})

def ListProjects(request):
    projects = Project.objects.all()
    return render(request, 'project/project_list.html', {'projects': projects})