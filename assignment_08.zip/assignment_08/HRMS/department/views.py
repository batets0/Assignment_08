from django.shortcuts import render
from attendance.models import DepartmentForm
from attendance.models import Department
# Create your views here.

def index(request):
    return render(request, 'department/index.html')

def ListDepartments(request):
    departments = Department.objects.all()
    return render(request, 'department/department_list.html', {'departments': departments})

def AddDepartment(request):
    form = DepartmentForm()
    if request.method == 'POST':
        form = DepartmentForm(request.POST)
        if form.is_valid():
            form.save()
        return index(request)   
    return render(request, 'department/add_department.html', {'form': form})
