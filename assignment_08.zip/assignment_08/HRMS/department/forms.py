from django import forms
from department.models import Department

# Create your forms here.
class DepartmentForm(forms.ModelForm):
    class Meta:
        model = Department
        fields = '__all__'