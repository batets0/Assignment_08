from django.shortcuts import render
from position.models import PositionForm
from position.models import Position
# Create your views here.

def index(request):
    return render(request, 'position/index.html')

def AddPosition(request):
    form = PositionForm()
    if request.method == 'POST':
        form = PositionForm(request.POST)
        if form.is_valid():
            form.save()
        return index(request)   
    return render(request, 'position/add_position.html', {'form': form})

def ListPositions(request):
    positions = Position.objects.all()
    return render(request, 'position/position_list.html', {'positions': positions})
