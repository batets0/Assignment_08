from django import forms
from position.models import Position

class PositionForm(forms.ModelForm):
    class Meta:
        model = Position
        fields = '__all__'