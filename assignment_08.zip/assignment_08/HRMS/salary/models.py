from django.db import models

from HRMS.employee.models import Employee

# Create your models here.
class Salary(models.Model):
    salary_id = models.AutoField(primary_key=True)
    employee = models.OneToOneField(Employee, on_delete=models.CASCADE)  # One-to-One relationship
    salary_amount = models.DecimalField(max_digits=10, decimal_places=2)
    effective_date = models.DateField()

    def __str__(self):
        return f"{self.employee.name} - {self.salary_amount}"

