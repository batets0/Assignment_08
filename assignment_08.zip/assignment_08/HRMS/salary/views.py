from django.shortcuts import render
from salary.models import SalaryForm
from salary.models import Salary
# Create your views here.

def list_salary(request):
    salary = Salary.objects.all()
    return render(request, 'salary/salary_list.html', {'salary': salary})

