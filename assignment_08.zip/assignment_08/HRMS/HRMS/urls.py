"""
URL configuration for HRMS project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import  path
from attendance import views
from department import views
from project import views
from employee import views
from performance_review import views
from salary import views
from training import views
from position import views


urlpatterns = [
    path('admin/', admin.site.urls),
    path('attendance/', views.index),
    path('department/', views.index),
    path('project/', views.index),
    path('employee/', views.index),
    path('performance_review/', views.index),
    path('salary/', views.index),
    path('training/', views.index),
    path('position/', views.index),
    path('addAttendance/', views.addAttendance),
    path('addDepartment/', views.addDepartment),
    path('addProject/', views.addProject),
    path('addEmployee/', views.addEmployee),
    path('addPerformanceReview/', views.addPerformanceReview),
    path('addSalary/', views.addSalary),
    path('addTraining/', views.addTraining),
    path('addPosition/', views.addPosition),
    path('listAttendance/', views.listAttendance),
    path('listDepartment/', views.listDepartment),
    path('listProject/', views.listProject),
    path('listEmployee/', views.listEmployee),
    path('listPerformanceReview/', views.listPerformanceReview),
    path('listSalary/', views.listSalary),
    path('listTraining/', views.listTraining),
    path('listPosition/', views.listPosition),
]
