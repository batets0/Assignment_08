from django.db import models
from django.db.models import Avg, Count

# Create your models here.
class Department(models.Model): 
    """
    Represents a department within the organization.
    
    This model stores information about different departments, which can be 
    associated with employees.
    """
    department_name = models.CharField(max_length=100)

    def __str__(self):
        return self.department_name

class Position(models.Model):
    """
    Represents a job position within the organization.
    
    This model stores information about different job positions that 
    employees can hold.
    """
    position_name = models.CharField(max_length=100)

    def __str__(self):
        return self.position_name



class Employee(models.Model):
     """
    Represents an employee in the organization.
    
    This model stores basic information about employees and their associations
    with departments and positions.
    """
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    dob = models.DateField()
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    position = models.ForeignKey(Position, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.first_name} {self.last_name}'


# Custom Query 1
class EmployeeQuerySet(models.QuerySet):
    def with_current_salary(self):
         """
        Annotates the queryset with the current salary of each employee.
        """
        return self.annotate(
            current_salary = models.Subquery(
                Salary.objects.filter(employee=models.OuterRef('pk'))
                .order_by('-effective_date')
                .values('salary_amount')[:1]))

    def with_project_count(self):
        """
        Annotates the queryset with the number of projects each employee is involved in.
        """
        return self.annotate(project_count=Count('employeeproject'))

    def with_average_performance(self):
        """
        Annotates the queryset with the average performance score of each employee.
        """
        return self.annotate(avg_performance=Avg('performancereview__score'))

    # Custom Query 2 
    objects = EmployeeQuerySet.as_manager()

    def get_current_salary(self):
        """
        Retrieves the current salary of the employee.
        
        Returns:
            The most recent Salary object associated with this employee.
        """
        return self.salary_set.order_by('-effective_date').first()

    def get_project_count(self):
        """
        Counts the number of projects the employee is currently involved in.
        
        Returns:
            An integer representing the number of associated EmployeeProject objects.
        """
        return self.employeeproject_set.count()

    def get_average_performance(self):
         """
        Calculates the average performance score of the employee.
        
        Returns:
            A float representing the average score from all PerformanceReview objects
            associated with this employee.
        """
        return self.performancereview_set.aggregate(Avg('score'))['score__avg']
  

class Salary(models.Model):
    """
    Represents the salary information for employees.
    
    This model allows tracking of salary changes over time for each employee.
    """
    employee = models.OneToOneField(Employee, on_delete=models.CASCADE)
    salary_amount = models.DecimalField(max_digits=10, decimal_places=2)
    effective_date = models.DateField()

    def __str__(self):
        return f'{self.employee} - {self.salary_amount}'

class Project(models.Model):
    """
    Represents a project within the organization.
    
    This model stores information about projects and their durations.
    """
    project_name = models.CharField(max_length=100)
    start_date = models.DateField()
    end_date = models.DateField()

    def __str__(self):
        return self.project_name

class Attendance(models.Model):
    """
    Represents employee attendance records.
    
    This model tracks daily attendance status for each employee.
    """
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    attendance_date = models.DateField()
    status = models.CharField(max_length=10, choices=[('Present', 'Present'), ('Absent', 'Absent')])

class PerformanceReview(models.Model):
    """
    Represents performance reviews for employees.
    
    This model stores performance review data including scores and comments.
    """
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    review_date = models.DateField()
    score = models.IntegerField()
    comments = models.TextField()

class Training(models.Model):
    """
    Represents training sessions offered to employees.
    
    This model tracks training programs and the employees who attended them.
    """
    training_name = models.CharField(max_length=100)
    training_date = models.DateField()

class EmployeeProject(models.Model):
    """
    Represents the association between employees and projects.
    
    This model serves as a through model for the many-to-many relationship
    between Employee and Project, allowing additional data like hours logged.
    """
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    project = models.ForeignKey(Project, on_delete=models.CASCADE)
    hours_logged = models.IntegerField()

    class Meta:
        unique_together = ('employee', 'project')

class EmployeeTraining(models.Model):
    """
    Represents the association between employees and trainings.
    
    This model serves as a through model for the many-to-many relationship
    between Employee and Training.
    """
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    training = models.ForeignKey(Training, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('employee', 'training')





