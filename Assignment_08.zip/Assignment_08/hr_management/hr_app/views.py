from django.shortcuts import render
from django.views.generic import ListView, DetailView, CreateView, UpdateView
from django.urls import reverse_lazy
from .models import Employee, Department, Project
# Create your views here.
class EmployeeListView(ListView):
    """
    Displays a list of all employees.
    
    This view uses the Employee model and annotates each employee with their
    current salary and the number of projects they're involved in.
    """
    model = Employee
    context_object_name = 'employees'
    template_name = 'hr_app/employee_list.html'

    def get_queryset(self):
        """
        Customizes the queryset to include current salary and project count.
        """
        return Employee.objects.with_current_salary().with_project_count()

class EmployeeDetailView(DetailView):
     """
    Displays detailed information about a specific employee.
    
    This view shows all relevant information about an employee, including
    their current salary, project count, and average performance score.
    """
    model = Employee
    context_object_name = 'employee'
    template_name = 'hr_app/employee_detail.html'

    def get_context_data(self, **kwargs):
        """
        Adds additional context data for the employee detail view.
        """
        context = super().get_context_data(**kwargs)
        context['current_salary'] = self.object.get_current_salary()
        context['project_count'] = self.object.get_project_count()
        context['avg_performance'] = self.object.get_average_performance()
        return context

class EmployeeCreateView(CreateView):
    """
    Provides a form for creating a new employee.
    
    This view allows users to create a new Employee object by filling out
    a form with the necessary fields.
    """
    model = Employee
    fields = ['name', 'dob', 'department', 'position']
    template_name = 'hr_app/employee_form.html'
    success_url = reverse_lazy('employee-list')

class EmployeeUpdateView(UpdateView):
    """
    Provides a form for updating an existing employee's information.
    
    This view allows users to modify the details of an existing Employee object.
    """
    model = Employee
    fields = ['name', 'dob', 'department', 'position']
    template_name = 'hr_app/employee_form.html'
    success_url = reverse_lazy('employee-list')

class DepartmentListView(ListView):
     """
    Displays a list of all departments.
    
    This view shows all departments in the organization.
    """
    model = Department
    context_object_name = 'departments'
    template_name = 'hr_app/department_list.html'

class ProjectListView(ListView):
     """
    Displays a list of all projects.
    
    This view shows all projects in the organization.
    """
    model = Project
    context_object_name = 'projects'
    template_name = 'hr_app/project_list.html'
