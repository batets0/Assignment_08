from django.test import TestCase, Client
from django.urls import reverse
from django.utils import timezone
from .models import Department, Position, Employee, Salary, Project, EmployeeProject
from decimal import Decimal

# Create your tests here.
class ModelTestCase(TestCase):
    def setUp(self):
        self.department = Department.objects.create(department_name="IT")
        self.position = Position.objects.create(position_name="Developer")
        self.employee = Employee.objects.create(
            name="John Doe",
            dob="1990-01-01",
            department=self.department,
            position=self.position
        )
        self.salary = Salary.objects.create(
            employee=self.employee,
            salary_amount=50000,
            effective_date=timezone.now().date()
        )
        self.project = Project.objects.create(
            project_name="Test Project",
            start_date=timezone.now().date(),
            end_date=timezone.now().date() + timezone.timedelta(days=30)
        )
        self.employee_project = EmployeeProject.objects.create(
            employee=self.employee,
            project=self.project,
            hours_logged=40
        )

    def test_employee_str(self):
        self.assertEqual(str(self.employee), "John Doe")

    def test_employee_get_current_salary(self):
        self.assertEqual(self.employee.get_current_salary().salary_amount, Decimal('50000.00'))

    def test_employee_get_project_count(self):
        self.assertEqual(self.employee.get_project_count(), 1)

class ViewTestCase(TestCase):
    def setUp(self):
        self.client = Client()
        self.department = Department.objects.create(department_name="IT")
        self.position = Position.objects.create(position_name="Developer")
        self.employee = Employee.objects.create(
            name="Jane Doe",
            dob="1995-01-01",
            department=self.department,
            position=self.position
        )

    def test_employee_list_view(self):
        response = self.client.get(reverse('employee-list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Jane Doe")

    def test_employee_detail_view(self):
        response = self.client.get(reverse('employee-detail', args=[self.employee.id]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Jane Doe")
        self.assertContains(response, "IT")
        self.assertContains(response, "Developer")

    def test_employee_create_view(self):
        response = self.client.post(reverse('employee-create'), {
            'name': 'New Employee',
            'dob': '1992-01-01',
            'department': self.department.id,
            'position': self.position.id
        })
        self.assertEqual(response.status_code, 302)  # Redirect after successful creation
        self.assertTrue(Employee.objects.filter(name='New Employee').exists())

    def test_employee_update_view(self):
        response = self.client.post(reverse('employee-update', args=[self.employee.id]), {
            'name': 'Updated Name',
            'dob': '1995-01-01',
            'department': self.department.id,
            'position': self.position.id
        })
        self.assertEqual(response.status_code, 302)  # Redirect after successful update
        self.employee.refresh_from_db()
        self.assertEqual(self.employee.name, 'Updated Name')

    def test_department_list_view(self):
        response = self.client.get(reverse('department-list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "IT")

    def test_project_list_view(self):
        project = Project.objects.create(
            project_name="Test Project",
            start_date=timezone.now().date(),
            end_date=timezone.now().date() + timezone.timedelta(days=30)
        )
        response = self.client.get(reverse('project-list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Test Project")