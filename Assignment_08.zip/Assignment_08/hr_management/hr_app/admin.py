from django.contrib import admin
from .models import Department, Position, Employee, Salary, Project, EmployeeProject, Attendance, PerformanceReview, Training, EmployeeTraining

# Register your models here.

@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ('name', 'department', 'position', 'get_current_salary')
    list_filter = ('department', 'position')
    search_fields = ('name', 'department__department_name', 'position__position_name')

@admin.register(Salary)
class SalaryAdmin(admin.ModelAdmin):
    list_display = ('employee', 'salary_amount', 'effective_date')
    list_filter = ('effective_date',)
    search_fields = ('employee__name',)

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('project_name', 'start_date', 'end_date')
    list_filter = ('start_date', 'end_date')
    search_fields = ('project_name',)

admin.site.register(Department)
admin.site.register(Position)
admin.site.register(EmployeeProject)
admin.site.register(Attendance)
admin.site.register(PerformanceReview)
admin.site.register(Training)
admin.site.register(EmployeeTraining)