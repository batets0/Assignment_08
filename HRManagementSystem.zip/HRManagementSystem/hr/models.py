from django.db import models
from django.db.models import Sum, Avg
# Create your models here.

# Department model
class Department(models.Model):
    department_name = models.CharField(max_length=100)

    def __str__(self):
        return self.department_name

    def total_employees(self):
        """
        Returns the total number of employees in this department.
        """
        return self.employee_set.count()

# Position model
class Position(models.Model):
    position_name = models.CharField(max_length=100)

    def __str__(self):
        return self.position_name

# Employee model
class Employee(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    dob = models.DateField()
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    position = models.ForeignKey(Position, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.first_name} {self.last_name}'

    # Method to get the full name
    def full_name(self):
        return f'{self.first_name} {self.last_name}'

    # Example method to calculate total working days from attendance
    def total_working_days(self):
        return self.attendance_set.filter(status='Present').count()

# Salary model
class Salary(models.Model):
    employee = models.OneToOneField(Employee, on_delete=models.CASCADE)
    salary_amount = models.DecimalField(max_digits=10, decimal_places=2)
    effective_date = models.DateField()

    def __str__(self):
        return f'{self.employee.full_name()} - {self.salary_amount}'

# Attendance model
class Attendance(models.Model):
    STATUS_CHOICES = [
        ('Present', 'Present'),
        ('Absent', 'Absent'),
    ]
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    attendance_date = models.DateField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES)

    def __str__(self):
        return f'{self.employee.full_name()} - {self.attendance_date} - {self.status}'

# PerformanceReview model
class PerformanceReview(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    review_date = models.DateField()
    score = models.IntegerField()
    comments = models.TextField()

    def __str__(self):
        return f'{self.employee.full_name()} - {self.review_date} - {self.score}'

# Training model
class Training(models.Model):
    training_name = models.CharField(max_length=100)
    training_date = models.DateField()

    def __str__(self):
        return self.training_name

# Project model
class Project(models.Model):
    project_name = models.CharField(max_length=100)
    start_date = models.DateField()
    end_date = models.DateField()
    employees = models.ManyToManyField(Employee, through='EmployeeProject')

    def __str__(self):
        return self.project_name

    # Example method to calculate total hours worked by all employees on this project
    def total_hours_worked(self):
        return self.employeeproject_set.aggregate(total_hours=models.Sum('hours_logged'))['total_hours']

# Many-to-Many relationship between Employee and Project with additional information (hours logged)
class EmployeeProject(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    project = models.ForeignKey(Project, on_delete=models.CASCADE)
    hours_logged = models.IntegerField()

    class Meta:
        unique_together = ('employee', 'project')

    def __str__(self):
        return f'{self.employee.full_name()} - {self.project.project_name} - {self.hours_logged} hours'

# Many-to-Many relationship between Employee and Training
class EmployeeTraining(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    training = models.ForeignKey(Training, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('employee', 'training')

    def __str__(self):
        return f'{self.employee.full_name()} - {self.training.training_name}'
