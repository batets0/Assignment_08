from django.shortcuts import render

# Create your views here.
from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, UpdateView
from .models import Employee, Department, Project

# List View to list all employees
class EmployeeListView(ListView):
    """
    View to list all employees in the database.

    Uses Django's ListView to render a list of Employee objects.
    """
    model = Employee
    template_name = 'employee_list.html'
    context_object_name = 'employees'  # Use 'employees' in the template to refer to the queryset


# Detail View to show employee details
class EmployeeDetailView(DetailView):
    """
    View to display the details of a specific employee.

    Uses Django's DetailView to render details of a single Employee object.
    """
    model = Employee
    template_name = 'employee_detail.html'
    context_object_name = 'employee'  # Use 'employee' in the template to refer to the object


# Create View to add a new employee
class EmployeeCreateView(CreateView):
    """
    View to create a new employee.

    Uses Django's CreateView to render a form for creating a new Employee object.
    On success, redirects to the employee list.
    """
    model = Employee
    template_name = 'employee_form.html'
    fields = ['first_name', 'last_name', 'dob', 'department', 'position']
    success_url = reverse_lazy('employee_list')  # Redirect to employee list after a successful creation


# Update View to edit an existing employee
class EmployeeUpdateView(UpdateView):
    """
    View to update an existing employee's details.

    Uses Django's UpdateView to render a form for updating an existing Employee object.
    On success, redirects to the employee list.
    """
    model = Employee
    template_name = 'employee_form.html'
    fields = ['first_name', 'last_name', 'dob', 'department', 'position']
    success_url = reverse_lazy('employee_list')  # Redirect to employee list after a successful update

# List View to list all projects
class ProjectListView(ListView):
    """
    View to list all projects in the database.

    Uses Django's ListView to render a list of Project objects.
    """
    model = Project
    template_name = 'project_list.html'
    context_object_name = 'projects'


# Detail View to show project details
class ProjectDetailView(DetailView):
    """
    View to display the details of a specific project.

    Uses Django's DetailView to render details of a single Project object.
    """
    model = Project
    template_name = 'project_detail.html'
    context_object_name = 'project'


# Create View to add a new project
class ProjectCreateView(CreateView):
    """
    View to create a new project.

    Uses Django's CreateView to render a form for creating a new Project object.
    On success, redirects to the project list.
    """
    model = Project
    template_name = 'project_form.html'
    fields = ['project_name', 'start_date', 'end_date']
    success_url = reverse_lazy('project_list')


# Update View to assign employees to a project
class ProjectUpdateView(UpdateView):
    """
    View to assign employees to an existing project.

    Uses Django's UpdateView to render a form for updating the list of employees assigned to a project.
    On success, redirects to the project list.
    """
    model = Project
    template_name = 'project_form.html'
    fields = ['project_name', 'start_date', 'end_date', 'employees']
    success_url = reverse_lazy('project_list')

# List View to list all departments
class DepartmentListView(ListView):
    """
    View to list all departments in the database.

    Uses Django's ListView to render a list of Department objects.
    """
    model = Department
    template_name = 'department_list.html'
    context_object_name = 'departments'


# Detail View to show department details
class DepartmentDetailView(DetailView):
    """
    View to display the details of a specific department.

    Uses Django's DetailView to render details of a single Department object.
    """
    model = Department
    template_name = 'department_detail.html'
    context_object_name = 'department'


# Create View to add a new department
class DepartmentCreateView(CreateView):
    """
    View to create a new department.

    Uses Django's CreateView to render a form for creating a new Department object.
    On success, redirects to the department list.
    """
    model = Department
    template_name = 'department_form.html'
    fields = ['department_name']
    success_url = reverse_lazy('department_list')


# Update View to edit an existing department
class DepartmentUpdateView(UpdateView):
    """
    View to update an existing department's details.

    Uses Django's UpdateView to render a form for updating a Department object.
    On success, redirects to the department list.
    """
    model = Department
    template_name = 'department_form.html'
    fields = ['department_name']
    success_url = reverse_lazy('department_list')
