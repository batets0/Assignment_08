from django.contrib import admin
from .models import Department, Position, Employee, Salary, Attendance, PerformanceReview, Training, Project, EmployeeProject, EmployeeTraining
# Register your models here.


# Customize the Department admin interface
@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ('department_name', 'total_employees')  # Display department name and total employees
    search_fields = ('department_name',)  # Search by department name

    def total_employees(self, obj):
        """
        Returns the total number of employees in a department.
        """
        return obj.employee_set.count()
    total_employees.short_description = 'Total Employees'


# Customize the Position admin interface
@admin.register(Position)
class PositionAdmin(admin.ModelAdmin):
    list_display = ('position_name',)
    search_fields = ('position_name',)


# Customize the Employee admin interface
@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'department', 'position', 'dob')  # Display employee details
    search_fields = ('first_name', 'last_name', 'department__department_name', 'position__position_name')  # Search by name, department, or position
    list_filter = ('department', 'position')  # Filter by department and position


# Customize the Salary admin interface
@admin.register(Salary)
class SalaryAdmin(admin.ModelAdmin):
    list_display = ('employee', 'salary_amount', 'effective_date')  # Display salary info
    search_fields = ('employee__first_name', 'employee__last_name')  # Search by employee name
    list_filter = ('effective_date',)  # Filter by effective date


# Customize the Attendance admin interface
@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ('employee', 'attendance_date', 'status')  # Display attendance details
    search_fields = ('employee__first_name', 'employee__last_name')  # Search by employee name
    list_filter = ('attendance_date', 'status')  # Filter by date and status


# Customize the PerformanceReview admin interface
@admin.register(PerformanceReview)
class PerformanceReviewAdmin(admin.ModelAdmin):
    list_display = ('employee', 'review_date', 'score', 'comments')  # Display performance review details
    search_fields = ('employee__first_name', 'employee__last_name')  # Search by employee name
    list_filter = ('review_date', 'score')  # Filter by date and score


# Customize the Training admin interface
@admin.register(Training)
class TrainingAdmin(admin.ModelAdmin):
    list_display = ('training_name', 'training_date')  # Display training name and date
    search_fields = ('training_name',)  # Search by training name
    list_filter = ('training_date',)  # Filter by training date


# Customize the Project admin interface
@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('project_name', 'start_date', 'end_date', 'total_hours_worked')  # Display project details
    search_fields = ('project_name',)  # Search by project name
    list_filter = ('start_date', 'end_date')  # Filter by start and end dates

    def total_hours_worked(self, obj):
        """
        Returns the total hours worked by employees on a project.
        """
        return obj.total_hours_worked()
    total_hours_worked.short_description = 'Total Hours Worked'


# Customize the EmployeeProject admin interface
@admin.register(EmployeeProject)
class EmployeeProjectAdmin(admin.ModelAdmin):
    list_display = ('employee', 'project', 'hours_logged')  # Display employee, project, and hours logged
    search_fields = ('employee__first_name', 'employee__last_name', 'project__project_name')  # Search by employee name or project name
    list_filter = ('project',)  # Filter by project


# Customize the EmployeeTraining admin interface
@admin.register(EmployeeTraining)
class EmployeeTrainingAdmin(admin.ModelAdmin):
    list_display = ('employee', 'training')  # Display employee and training
    search_fields = ('employee__first_name', 'employee__last_name', 'training__training_name')  # Search by employee or training
    list_filter = ('training',)  # Filter by training
