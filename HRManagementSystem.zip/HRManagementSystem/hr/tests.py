from django.test import TestCase
from django.urls import reverse
from .models import Employee, Department, Position
# Create your tests here.



class EmployeeViewTests(TestCase):
    def setUp(self):
        """
        Set up test data for Employee tests.
        Create a department, position, and employee.
        """
        self.department = Department.objects.create(department_name="HR")
        self.position = Position.objects.create(position_name="Manager")
        self.employee = Employee.objects.create(
            first_name="John",
            last_name="Doe",
            dob="1990-01-01",
            department=self.department,
            position=self.position
        )
    
    def test_employee_list_view(self):
        """
        Test that the employee list view renders correctly.
        """
        response = self.client.get(reverse('employee_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "John Doe")
        self.assertTemplateUsed(response, 'employee_list.html')
    
    def test_employee_detail_view(self):
        """
        Test that the employee detail view renders correctly.
        """
        response = self.client.get(reverse('employee_detail', args=[self.employee.id]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "John Doe")
        self.assertTemplateUsed(response, 'employee_detail.html')
    
    def test_create_employee_view(self):
        """
        Test creating a new employee through the form.
        """
        response = self.client.post(reverse('employee_create'), {
            'first_name': 'Jane',
            'last_name': 'Doe',
            'dob': '1995-01-01',
            'department': self.department.id,
            'position': self.position.id
        })
        self.assertEqual(response.status_code, 302)  # Redirects after successful creation
        self.assertEqual(Employee.objects.count(), 2)
    
    def test_update_employee_view(self):
        """
        Test updating an employee through the form.
        """
        response = self.client.post(reverse('employee_update', args=[self.employee.id]), {
            'first_name': 'John',
            'last_name': 'Smith',  # Update last name
            'dob': '1990-01-01',
            'department': self.department.id,
            'position': self.position.id
        })
        self.assertEqual(response.status_code, 302)  # Redirects after successful update
        self.employee.refresh_from_db()
        self.assertEqual(self.employee.last_name, 'Smith')


class DepartmentViewTests(TestCase):
    def setUp(self):
        """
        Set up test data for Department tests.
        Create a department for testing.
        """
        self.department = Department.objects.create(department_name="Engineering")
    
    def test_department_list_view(self):
        """
        Test that the department list view renders correctly.
        """
        response = self.client.get(reverse('department_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Engineering")
        self.assertTemplateUsed(response, 'department_list.html')
    
    def test_department_detail_view(self):
        """
        Test that the department detail view renders correctly.
        """
        response = self.client.get(reverse('department_detail', args=[self.department.id]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Engineering")
        self.assertTemplateUsed(response, 'department_detail.html')
