from django.urls import path
from . import views
from .views import EmployeeListView, EmployeeDetailView, EmployeeCreateView, EmployeeUpdateView
from .views import ProjectListView, ProjectDetailView, ProjectCreateView, ProjectUpdateView
from .views import DepartmentListView, DepartmentDetailView, DepartmentCreateView, DepartmentUpdateView

urlpatterns = [
    # Employee URLs
    path('employees/', EmployeeListView.as_view(), name='employee_list'),
    path('employees/<int:pk>/', EmployeeDetailView.as_view(), name='employee_detail'),
    path('employees/new/', EmployeeCreateView.as_view(), name='employee_create'),
    path('employees/edit/<int:pk>/', EmployeeUpdateView.as_view(), name='employee_update'),

    # Project URLs
    path('projects/', ProjectListView.as_view(), name='project_list'),
    path('projects/<int:pk>/', ProjectDetailView.as_view(), name='project_detail'),
    path('projects/new/', ProjectCreateView.as_view(), name='project_create'),
    path('projects/edit/<int:pk>/', ProjectUpdateView.as_view(), name='project_update'),

    # Department URLs
    path('departments/', DepartmentListView.as_view(), name='department_list'),
    path('departments/<int:pk>/', DepartmentDetailView.as_view(), name='department_detail'),
    path('departments/new/', DepartmentCreateView.as_view(), name='department_create'),
    path('departments/edit/<int:pk>/', DepartmentUpdateView.as_view(), name='department_update'),
]
